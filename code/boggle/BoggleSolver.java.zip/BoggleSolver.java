import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.TrieSET;

public class BoggleSolver {
    // Initializes the data structure using the given array of strings as the dictionary.
    // (You can assume each word in the dictionary contains only the uppercase letters A through Z.)
    private TrieSET dict;
    private int[] dx = { -1, 0, 1, 1, 1, 0, -1, -1 };
    private int[] dy = { -1, -1, -1, 0, 1, 1, 1, 0 };

    public BoggleSolver(String[] dictionary) {
        dict = new TrieSET();
        for (String s : dictionary) dict.add(s);
    }

    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board) {
        SET<String> validWords = new SET<>();
        for (int i = 0; i < board.rows(); i++) {
            for (int j = 0; j < board.cols(); j++) {
                Stack<Node> dfs = new Stack<>();

                String start = "" + board.getLetter(i, j);
                if (start.equals("Q")) start += "U";
                dfs.push(new Node(start, i, j, board.rows(), board.cols()));

                while (!dfs.isEmpty()) {
                    Node node = dfs.pop();
                    int r = node.getRow();
                    int c = node.getCol();
                    for (int k = 0; k < 8; k++) {
                        int rr = r + dy[k];
                        int cc = c + dx[k];

                        if (rr < 0 || rr >= board.rows() || cc < 0 || cc >= board.cols()
                                || node.getVis()[rr][cc]) continue;

                        char curr = board.getLetter(rr, cc);
                        String ss = node.getString() + curr;
                        if (curr == 'Q') ss += "U";
                        if (((Queue<String>) dict.keysWithPrefix(ss)).isEmpty()) continue;
                        if (dict.contains(ss) && ss.length() > 2) {
                            validWords.add(ss);
                            // StdOut.println(ss);
                        }

                        boolean[][] newVis = new boolean[board.rows()][board.cols()];
                        for (int x = 0; x < board.rows(); x++)
                            for (int y = 0; y < board.cols(); y++)
                                newVis[x][y] = node.getVis()[x][y];


                        newVis[rr][cc] = true;

                        dfs.push(new Node(ss, rr, cc,
                                          newVis));
                    }
                }

            }
        }

        return validWords;
    }

    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word) {
        int len = word.length();

        if (len <= 2) return 0;
        else if (len <= 4) return 1;
        else if (len == 5) return 2;
        else if (len == 6) return 3;
        else if (len == 7) return 5;
        else return 11;
    }

    private class Node {
        private String string;
        private int row;
        private int col;
        private boolean[][] vis;

        public Node(String s, int r, int c, int rows, int cols) {
            string = "" + s;
            row = r;
            col = c;
            vis = new boolean[rows][cols];
            vis[r][c] = true;
        }

        public Node(String s, int r, int c, boolean[][] vis) {
            // new node
            string = s;
            row = r;
            col = c;
            this.vis = vis;
        }

        public boolean[][] getVis() {
            return vis;
        }

        public int getCol() {
            return col;
        }

        public int getRow() {
            return row;
        }

        public String getString() {
            return string;
        }
    }

    public static void main(String[] args) {
        In in = new In(args[0]);
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(args[1]);
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
    }

}
